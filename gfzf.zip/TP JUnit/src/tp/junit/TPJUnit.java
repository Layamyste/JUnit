/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.junit;

/**
 *
 * @author SLAM
 */
public class TPJUnit {
    
    
    SommeArgent m12CHF= new SommeArgent(14,"CHF");//1
    
    SommeArgent m14CHF= new SommeArgent(14,"CHF");
    
    SommeArgent expected= new SommeArgent(26,"CHF");
    
    SommeArgent result = m12CHF.add(m14CHF);//(2)
    
    Assert.assertTrue(expected.equals(result));//(3)

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }}
    
}
