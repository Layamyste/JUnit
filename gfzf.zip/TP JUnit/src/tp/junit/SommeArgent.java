/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.junit;

import java.util.Objects;

/**
 *
 * @author SLAM
 */
public class SommeArgent {
    private int quantite;
    
    private String unite;
    
    public SommeArgent (int amount, String currency) {quantite = amount;
    
    unite = currency;
    }
    
    public int getQuantite(){
        return quantite;
    }
    
    public String getUnite(){
        return unite;
    }
    public SommeArgent add(SommeArgent m){
        
        return new
            SommeArgent(getQuantite()+m.getQuantite(), getUnite());
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public void setUnite(String unite) {
        this.unite = unite;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SommeArgent other = (SommeArgent) obj;
        if (this.quantite != other.quantite) {
            return false;
        }
        return Objects.equals(this.unite, other.unite);
    } 
    
            
            
}
